Matthew Michael Sherlin
Homework 5 for Systems Programming

Makefile runs as follows:
'make run' to create executable for function. It will create an executable under the name 'pipe'
Use './pipe' in order to run function

Use this syntax to execute program: ./pipe [directory] [[-s][-S][-t]]
You can exclude or include anything in brackets if you wish.

'make clean' in order to clean up the executable. This will delete the executable and nothing else.

/////////////////
// PLEASE READ
/////////////////

If you are receiving an error on some attempts while entering a directory (ls: invalid option -- ''),
please add "/" to the end of the directory. This will solve the issue.
